#include "DSBaiTho.h"
void main()
{
	DSBaiTho a;
	a.KiemTra();
}