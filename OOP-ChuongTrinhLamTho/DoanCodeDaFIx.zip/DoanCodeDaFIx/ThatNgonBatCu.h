#pragma once
#include "BaiTho.h"
class ThatNgonBatCu : public BaiTho 
{

	//Y tuong:doan tho phai co 8 cau, 7 chu
	//kiem tra dieu kien tuong tu nhu 2 class tho luc bat va song that luc bat
public:
	void Nhap(); 
	bool KiemTra(); 
};